# Taller 01: Modelos Matemáticos y Estadísticos Clásicos
## Guía de Ejecución, Estudio y Estructura del Proyecto

¡Bienvenido! Este proyecto contiene la resolución del **Taller 01**, enfocado en la manipulación de datos, limpieza, unión de tablas y la construcción de un **Maestro de Clientes Resumen** para una empresa de comercio electrónico.

El proyecto ha sido diseñado emulando el proceso de un estudiante en etapa de aprendizaje, con un enfoque didáctico, código muy legible y comentarios explicativos exhaustivos de cada decisión lógica tomada.

---

## 📁 Estructura del Proyecto

El espacio de trabajo está organizado de la siguiente manera:

*   `data/` : Directorio que contiene los datasets del proyecto.
    *   `customers.csv` : Datos crudos de clientes.
    *   `products.csv` : Catálogo físico de productos.
    *   `order_items.csv` : Detalle transaccional de los artículos comprados.
    *   `orders.csv` : Encabezado de los pedidos y fechas logísticas.
    *   `maestro_clientes_resumen.csv` : **¡Resultado Final!** El maestro de clientes unificado y calculado por el notebook.
*   `download_data.py` : Script automático en Python para descargar de forma segura los archivos CSV desde sus fuentes originales en Google Sheets.
*   `generate_notebook.py` : Script de automatización que ejecuta la lógica de análisis completa localmente y genera el notebook Jupyter pre-ejecutado.
*   `taller_01.ipynb` : **Notebook Jupyter Principal**. Contiene toda la inspección, explicaciones pedagógicas, código limpio y salidas tabulares para su estudio.
*   `respuestas.md` : Documento con las respuestas formales a las 5 preguntas del taller y las justificaciones cortas de una línea para cada proceso de limpieza, según la rúbrica.
*   `README.md` : Esta guía de usuario con instrucciones detalladas de ejecución.

---

## 🛠️ Requisitos de Software

Para ejecutar este proyecto de forma interactiva en tu computadora, necesitarás contar con:

1.  **Python 3.8 o superior** instalado en tu sistema.
2.  Las siguientes librerías de análisis de datos:
    *   `pandas` (para la manipulación de DataFrames)
    *   `numpy` (para operaciones numéricas)
3.  Un entorno de ejecución para notebooks, como:
    *   **Jupyter Notebook** o **JupyterLab** (instalables mediante pip).
    *   **VS Code** con la extensión de Jupyter instalada (altamente recomendado).
    *   **Google Colab** (subiendo el archivo `.ipynb` y los archivos CSV correspondientes).

---

## 🚀 Guía de Instalación y Ejecución Paso a Paso

Sigue estos simples pasos para configurar tu entorno y correr el proyecto en tu máquina local:

### Paso 1: Preparar tu entorno de desarrollo
Abre tu terminal o consola de comandos y navega hasta la carpeta del proyecto. Es una excelente práctica crear un entorno virtual para no interferir con otras instalaciones globales de tu computadora:

```bash
# Crear un entorno virtual llamado .venv (opcional pero recomendado)
python3 -m venv .venv

# Activar el entorno virtual
# En macOS/Linux:
source .venv/bin/activate
# En Windows:
.venv\Scripts\activate
```

### Paso 2: Instalar las dependencias
Una vez activo tu entorno virtual, instala las librerías necesarias con el gestor de paquetes de Python (`pip`):

```bash
# Instalar pandas, numpy y jupyter notebook
pip install pandas numpy jupyter notebook
```

### Paso 3: Descargar los datos automáticamente
Hemos provisto un script automatizado para descargar directamente las fuentes originales desde Google Sheets a tu carpeta local. Ejecútalo corriendo el siguiente comando:

```bash
python download_data.py
```
*Esto creará la carpeta `data/` (si no existe) y descargará los 4 archivos CSV automáticamente.*

### Paso 4: Abrir y Ejecutar el Notebook Jupyter
Puedes abrir el archivo `taller_01.ipynb` utilizando el comando tradicional de Jupyter:

```bash
jupyter notebook
```
Esto abrirá una pestaña en tu navegador. Selecciona el archivo `taller_01.ipynb` y podrás interactuar con él. 

*   Si deseas volver a ejecutar todo el análisis desde cero para comprobar los resultados, ve al menú superior de Jupyter y haz clic en **Kernel -> Restart & Run All**.
*   Si estás usando **VS Code**, simplemente abre la carpeta del proyecto en VS Code, selecciona `taller_01.ipynb` y haz clic en el botón **"Run All"** en la parte superior del archivo.

---

## 📚 ¿Cómo Estudiar Este Proyecto?

Si estás aprendiendo análisis de datos o ciencia de datos, te sugerimos estudiar los archivos en el siguiente orden lógico:

1.  **`README.md`:** (Este documento) para entender cómo está configurado todo.
2.  **`respuestas.md`:** Para leer las conclusiones principales del negocio y entender el porqué de cada decisión de limpieza a nivel macro, con justificaciones que se alinean rigurosamente con la rúbrica del curso.
3.  **`taller_01.ipynb`:** Para sumergirte en el código de Python. Sigue las celdas secuencialmente; están escritas con comentarios conversacionales que explican los "porqués" de cada paso y muestran detalladamente el análisis exploratorio (`head()`, `info()`, `isnull().sum()`), el análisis de los nulos y duplicados, los merges paso a paso, y la lógica matemática detrás de las agregaciones.

¡Esperamos que este proyecto te sea de enorme utilidad en tu aprendizaje de Ciencia de Datos y Modelos Estadísticos Clásicos!
