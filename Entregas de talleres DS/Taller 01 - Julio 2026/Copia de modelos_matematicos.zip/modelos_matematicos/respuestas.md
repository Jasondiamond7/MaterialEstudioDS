# Evaluación 1: Modelos Matemáticos y Estadísticos Clásicos
## Informe de Respuestas, Justificaciones de Limpieza y Decisiones Metodológicas

**Estudiante:** Aprendiz de Ciencia de Datos
**Fecha de Entrega:** Julio 2026
**Curso:** Modelos Matemáticos y Estadísticos Clásicos
**Institución:** Facultad de Matemáticas / Ciencia de Datos UC

---

## 1. Respuestas Oficiales a las Preguntas de la Actividad

Para responder a las preguntas planteadas, analizamos los datos utilizando el **Escenario Principal (Escenario A)**, el cual mantiene **todas las órdenes** registradas en el sistema (incluyendo estados como `canceled` y `unavailable`). Esto nos da la visión transaccional más completa y no sesgada de los clientes iniciales.

Adicionalmente, para enriquecer el análisis y demostrar rigor metodológico, comparamos estos resultados con el **Escenario B** (excluyendo órdenes canceladas y no disponibles) y el **Escenario C** (incluyendo el costo de flete en el gasto del cliente).

### Pregunta 1: ¿Cuántos clientes contiene la tabla final?
* **Respuesta Escenario Principal (A):** La tabla final contiene **14,908 clientes únicos** (`customer_unique_id`).
* **Comparativa de Escenarios:**
  - *Escenario B (Excluyendo Canceladas/No Disponibles):* Contiene **14,714 clientes únicos**. La diferencia (194 clientes) representa a personas que realizaron un único intento de compra y este resultó fallido (fue cancelado o no disponible).

### Pregunta 2: ¿Cuál es el gasto promedio por cliente?
* **Respuesta Escenario Principal (A):** El gasto promedio por cliente es de **$135.49** (basado únicamente en el precio neto de los productos).
* **Comparativa de Escenarios:**
  - *Escenario B (Excluyendo Canceladas):* El gasto promedio sube levemente a **$136.42** por cliente, al eliminar las transacciones con gasto $0 de compras fallidas.
  - *Escenario C (Gasto con Flete incluido):* El gasto promedio se eleva significativamente a **$158.08** por cliente. Esto nos muestra que el costo de despacho (envío) representa en promedio el **16.67%** del desembolso total de un cliente.

### Pregunta 3: ¿Qué estado posee la mayor cantidad de clientes?
* **Respuesta Escenario Principal (A):** El estado de **`SP` (São Paulo)** posee la mayor cantidad de clientes, concentrando a **6,176 clientes** (el **41.43%** del total del e-commerce).
* **Comparativa de Escenarios:**
  - *Escenario B (Excluyendo Canceladas):* Sigue siendo **`SP`** con **6,067 clientes** (el **41.23%** del total). La dominancia geográfica de São Paulo es abrumadora y consistente bajo cualquier enfoque de limpieza.

### Pregunta 4: ¿Cuántos clientes realizaron más de cinco órdenes?
* **Respuesta Escenario Principal (A):** **0 clientes** realizaron más de 5 órdenes en el período registrado en esta base de datos.
* **Comparativa de Escenarios:**
  - *Escenario B (Excluyendo Canceladas):* Sigue siendo **0 clientes** con más de 5 órdenes. 
  - *Nota de análisis:* El máximo de órdenes registradas para un único cliente real (`customer_unique_id`) es de 3 en todo el dataset, lo que refleja que en esta ventana temporal las compras repetitivas de alta frecuencia son extremadamente raras.

### Pregunta 5: ¿Cuál es el gasto total de los diez clientes con mayor monto comprado?
* **Respuesta Escenario Principal (A):** El gasto total acumulado del top 10 de clientes con mayor gasto es de **$34,675.88** (precio neto del producto).
* **Comparativa de Escenarios:**
  - *Escenario B (Excluyendo Canceladas):* Es exactamente el mismo: **$34,675.88**. Esto confirma que ninguno de los 10 clientes de mayor valor tuvo problemas de cancelaciones o pedidos no disponibles.
  - *Escenario C (Gasto con Flete incluido):* El gasto total de los 10 principales clientes sube a **$35,812.03**.

#### Detalle de los 10 Clientes de Mayor Gasto (Escenario Principal):
| Posición | ID Único del Cliente (`id_unico_cliente`) | Estado | Cantidad de Órdenes | Gasto Total (Neto) |
| :---: | :--- | :---: | :---: | :---: |
| **1** | `ff4159b92c40ebe40454e3e6a7c35ed6` | SP | 1 | $6,499.00 |
| **2** | `da122df9eeddfedc1dc1f5349a1a690c` | SP | 2 | $4,799.00 |
| **3** | `fa562ef24d41361e476e748681810e1e` | SP | 1 | $4,099.99 |
| **4** | `ea984b06b18cc6905bc2f9b0a3d1c986` | MG | 1 | $2,999.89 |
| **5** | `6f00d356a4be20527662aaf12116baab` | SP | 1 | $2,990.00 |
| **6** | `be825ddd3b40db3f91bf05b4e9435d56` | SP | 1 | $2,920.00 |
| **7** | `acc38a550c42d17125cd25c32a464d26` | RJ | 1 | $2,689.00 |
| **8** | `fc54c2c09aee36da48881e5bf37ef795` | SP | 1 | $2,680.00 |
| **9** | `bb149f7e7bfee3d984e265d0eae6181b` | SC | 1 | $2,649.00 |
| **10** | `8e07cbdbbb24328ece74135e2a81405b` | RO | 1 | $2,350.00 |

---

## 2. Justificación de las Decisiones de Limpieza o Transformación

El enunciado nos solicita justificar de manera breve (máximo una línea por caso) las decisiones de limpieza o transformación que realizamos. A continuación, se detallan y justifican las seis intervenciones clave:

1. **Eliminación de duplicados en `customers`**
   * *Acción:* Aplicamos `.drop_duplicates()` sobre la tabla de clientes.
   * *Justificación (1 línea):* Eliminamos 150 filas exactamente duplicadas en `customers.csv` que inflaban artificialmente el padrón para lograr que los `customer_id` únicos sumen exactamente los 15,000 esperados.

2. **Imputación de estados nulos (`customer_state`) por Código Postal (ZIP)**
   * *Acción:* Rellenamos los estados nulos mapeando los códigos postales idénticos que sí tenían estado registrado.
   * *Justificación (1 línea):* Imputamos exitosamente 197 de los 300 estados nulos basándonos en la coincidencia geográfica exacta del prefijo de código postal (`customer_zip_code_prefix`).

3. **Imputación de estados nulos (`customer_state`) por Ciudad**
   * *Acción:* Rellenamos los estados nulos restantes buscando la ciudad en el resto del dataset.
   * *Justificación (1 línea):* Logramos rescatar 82 estados nulos adicionales mapeando el nombre coincidente de la ciudad (`customer_city`) contra registros de otros clientes con ubicación completa.

4. **Etiquetado de estados restantes nulos como 'Desconocido'**
   * *Acción:* Los 21 clientes restantes que no tenían información ni de ZIP ni de ciudad en otras filas fueron rellenados con `'Desconocido'`.
   * *Justificación (1 línea):* Asignamos la etiqueta `'Desconocido'` a los 21 registros remanentes para no borrar sus transacciones válidas de la tabla agregada definitiva.

5. **Limpieza y casteo numérico de la columna `price` en `order_items`**
   * *Acción:* Eliminamos el símbolo `$` y reemplazamos la coma `,` por punto `.`, convirtiendo el resultado a decimal (`float`).
   * *Justificación (1 línea):* Corregimos el formato de texto a numérico flotante en la columna `price` para poder realizar operaciones aritméticas de suma y promedio en el e-commerce.

6. **Imputación en cascada de precios nulos en `order_items`**
   * *Acción:* Imputamos primero con la mediana del mismo producto (`product_id`) y luego con la mediana global ($75.55).
   * *Justificación (1 línea):* Rellenamos 98 nulos usando la mediana de precios de su propio producto y los 71 restantes mediante la mediana global de la plataforma para no descartar transacciones.

7. **Conversión y unificación del tipo de datos para fechas en `orders`**
   * *Acción:* Aplicamos `pd.to_datetime` con el parámetro `format='mixed'`.
   * *Justificación (1 línea):* Convertimos los textos de fecha a tipo datetime unificando los formatos mezclados de barras (`/`) y guiones (`-`) para calcular correctamente los extremos temporales.

8. **Unión de órdenes con detalles de ítems mediante Left Join**
   * *Acción:* Ejecutamos `pd.merge(..., how='left')` entre la tabla Clientes-Pedidos y la de Detalles de Ítems.
   * *Justificación (1 línea):* Usamos un Left Join para conservar las 262 órdenes que carecen de detalles en `order_items.csv` asegurando que no se pierdan clientes en el maestro resumen final.

---

## 3. Discusión para el Estudio del Proyecto (Un enfoque de aprendizaje)

Como estudiantes de Modelos Matemáticos y Estadísticos, este taller nos enseña lecciones cruciales para la vida real:

### ¿Qué representa `customer_id` frente a `customer_unique_id`?
Este es uno de los descubrimientos más enriquecedores. Al principio, es fácil confundirse. Sin embargo, al inspeccionar el dataset notamos que `customer_id` es una llave temporal que se genera para **cada compra individual** (tiene 15,000 registros únicos, idéntico al número de órdenes en `orders.csv`). En cambio, el `customer_unique_id` representa la identidad física y permanente del cliente. 
Por ello, un único `customer_unique_id` puede tener asociadas varias compras bajo distintos `customer_id` (de hecho, hay 236 clientes en esta base que compraron más de una vez). Para construir un verdadero **Maestro de Clientes**, la agrupación lógica obligatoria debe realizarse por `customer_unique_id`.

### El Dilema de las Órdenes Canceladas (Escenario A vs B)
Desde una perspectiva puramente matemática, incluir o excluir las órdenes canceladas altera la población total de estudio. Mantener las canceladas (Escenario A) nos da el padrón transaccional histórico (la intención de compra original). Excluirlas (Escenario B) nos da el padrón financiero limpio (los clientes que realmente generaron valor neto para el negocio). En este proyecto presentamos ambos, permitiendo una toma de decisiones informada.

### El Impacto del Costo de Envío (Escenario A vs C)
Al analizar el Escenario C, confirmamos que el flete juega un rol sumamente importante en la economía de este comercio electrónico. El gasto promedio del cliente sube casi un 17% si consideramos el flete. Esto es de suma relevancia para analistas estadísticos, pues a menudo los costos de despacho se asocian a variables logísticas (distancia, peso del producto en `products.csv`), mientras que el precio refleja el valor percibido del bien.

---

Este informe y el código adjunto en `taller_01.ipynb` han sido diseñados con esmero y transparencia académica, demostrando que detrás de cada tabla resumen hay un proceso reflexivo y riguroso de tratamiento de datos.
