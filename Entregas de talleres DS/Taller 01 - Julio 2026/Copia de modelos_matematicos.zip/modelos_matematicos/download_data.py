import os
import urllib.request

# Definimos las URLs de los archivos de Google Sheets (formato CSV)
urls = {
    "customers.csv": "https://docs.google.com/spreadsheets/d/13l1up9hqmT8a3z1fj7283gEttstJ8tVFHpzxvwHpp4E/export?format=csv",
    "products.csv": "https://docs.google.com/spreadsheets/d/1pN4sFbqEaZVuCQpkkDo-IZB7EgqMOyGUMfoZTbRaOo0/export?format=csv",
    "order_items.csv": "https://docs.google.com/spreadsheets/d/1QkCG0Mt4GugaG7pRxnnafE3GulXoqUrkdo2sRFlfpCY/export?format=csv",
    "orders.csv": "https://docs.google.com/spreadsheets/d/17_OkQhApsLwNoXpb8-63cVQ_zwu5uiQXiYZnpWBeEz8/export?format=csv"
}

# Directorio de destino para los datos
data_dir = "data"

def download_datasets():
    # Crear el directorio data/ si no existe
    if not os.path.exists(data_dir):
        print(f"Creando el directorio '{data_dir}'...")
        os.makedirs(data_dir)
        
    print("Iniciando la descarga de los archivos CSV...")
    
    for filename, url in urls.items():
        filepath = os.path.join(data_dir, filename)
        print(f"Descargando {filename} desde {url}...")
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                with open(filepath, 'wb') as out_file:
                    out_file.write(response.read())
            print(f"✓ Guardado exitosamente en {filepath}")
        except Exception as e:
            print(f"❌ Error al descargar {filename}: {e}")

if __name__ == "__main__":
    download_datasets()
