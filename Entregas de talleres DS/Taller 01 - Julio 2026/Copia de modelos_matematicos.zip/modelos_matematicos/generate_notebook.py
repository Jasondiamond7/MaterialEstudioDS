import json
import sys
import io
import os
import pandas as pd
import numpy as np

# Creamos una lista para almacenar las celdas del notebook
cells = []
execution_count = 1

# Estructuras para capturar el estado global de la ejecución
global_env = {
    'pd': pd,
    'np': np,
    'os': os,
}

def add_markdown(source_text):
    """Agrega una celda de Markdown al notebook."""
    cells.append({
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in source_text.strip().split("\n")]
    })

def add_code(source_code):
    """Ejecuta el código en el entorno global, captura la salida y agrega una celda de Código con output."""
    global execution_count
    
    # Redirigir stdout para capturar los prints
    old_stdout = sys.stdout
    redirected_output = io.StringIO()
    sys.stdout = redirected_output
    
    # Mock de la función display de Jupyter para que capture HTML y texto plano
    display_data = []
    def mock_display(*args):
        for arg in args:
            if isinstance(arg, pd.DataFrame):
                display_data.append({
                    "text/plain": arg.to_string(),
                    "text/html": arg._repr_html_()
                })
                # Imprimir también en consola para que quede registrado
                print(arg.to_string())
            elif isinstance(arg, pd.Series):
                display_data.append({
                    "text/plain": arg.to_string()
                })
                print(arg.to_string())
            else:
                display_data.append({
                    "text/plain": str(arg)
                })
                print(str(arg))
                
    global_env['display'] = mock_display
    
    error_occurred = None
    try:
        # Ejecutar el código en el entorno global
        exec(source_code, global_env)
    except Exception as e:
        error_occurred = e
    finally:
        # Restaurar stdout
        sys.stdout = old_stdout
        
    stdout_str = redirected_output.getvalue()
    
    # Estructura del output para Jupyter
    outputs = []
    
    # Si hubo salida de texto estándar (prints)
    if stdout_str:
        outputs.append({
            "name": "stdout",
            "output_type": "stream",
            "text": [line + "\n" for line in stdout_str.splitlines()]
        })
        
    # Si hubo displays de DataFrames/Series (capturados por el mock)
    for disp in display_data:
        outputs.append({
            "data": {
                "text/plain": [line + "\n" for line in disp["text/plain"].splitlines()],
                **({"text/html": [line + "\n" for line in disp["text/html"].splitlines()]} if "text/html" in disp else {})
            },
            "metadata": {},
            "output_type": "display_data"
        })
        
    # Si hubo error, capturamos el traceback
    if error_occurred:
        import traceback
        tb = traceback.format_exception(type(error_occurred), error_occurred, error_occurred.__traceback__)
        outputs.append({
            "ename": type(error_occurred).__name__,
            "evalue": str(error_occurred),
            "output_type": "error",
            "traceback": tb
        })
        print(f"❌ Error al ejecutar celda {execution_count}: {error_occurred}")
        traceback.print_exc()
        
    # Crear la celda de Jupyter
    cells.append({
        "cell_type": "code",
        "execution_count": execution_count,
        "metadata": {},
        "outputs": outputs,
        "source": [line + "\n" for line in source_code.splitlines()]
    })
    
    execution_count += 1


# ==============================================================================
# 1. INTRODUCCIÓN Y BIENVENIDA
# ==============================================================================
add_markdown("""
# Taller 01 - Modelos Matemáticos y Estadísticos Clásicos
## Análisis de Datos de Comercio Electrónico y Construcción del Maestro de Clientes

**Autor/Estudiante:** Aprendiz de Ciencia de Datos
**Fecha:** Julio 2026
**Docente:** Profesor del Curso
**Institución:** Facultad de Matemáticas / Ciencia de Datos UC

---

### Descripción del Proyecto
Este documento contiene el desarrollo completo del **Taller 1** para el curso de **Modelos matemáticos y estadísticos clásicos**. 

El objetivo es analizar cuatro archivos CSV proporcionados por una empresa de comercio electrónico (Olist) y construir un **Maestro de Clientes** unificado. No contamos inicialmente con un diccionario de datos, por lo que realizaremos una exploración sistemática para deducir las relaciones entre las tablas, limpiar los datos inconsistentes o nulos, corregir problemas de tipos y unificar todo en un dataset final que nos permita responder 5 preguntas estratégicas de negocio.

Este notebook ha sido diseñado de manera pedagógica y detallada, explicando cada decisión de análisis y limpieza que tomamos como si estuviéramos aprendiendo en el proceso.

---

### Estructura de Trabajo
1. **Lectura e Inspección de Datos:** Carga de los archivos CSV y análisis exploratorio inicial de sus columnas, dimensiones, tipos de datos y valores faltantes.
2. **Manipulación y Limpieza de Datos:** Corrección de formatos de fecha, parseo y conversión de columnas numéricas que estaban guardadas como texto, deduplicación de registros y tratamiento/imputación inteligente de valores nulos (estados de clientes y precios).
3. **Relación entre Tablas (Uniones):** Análisis de llaves, verificación de integridad referencial y combinación de las tablas utilizando `pd.merge()` de forma óptima.
4. **Construcción del Maestro de Clientes Final:** Agrupación a nivel de cliente y cálculo de las métricas solicitadas.
5. **Resolución de Preguntas de Negocio:** Respuestas detalladas para el escenario principal y comparación con escenarios alternativos (con/sin flete, con/sin órdenes canceladas).
6. **Guardado de Resultados:** Almacenamiento del maestro final en un archivo CSV.
""")

# ==============================================================================
# 2. IMPORTACIÓN DE LIBRERÍAS
# ==============================================================================
add_markdown("""
## 1. Importación de Librerías

Comenzamos importando las librerías necesarias. Para este análisis de datos, utilizaremos principalmente **Pandas** y **Numpy**, que son las herramientas fundamentales que estamos aprendiendo a utilizar para la manipulación y análisis de datos en Python.
""")

add_code(r"""
# Importamos las librerías necesarias para el análisis
import pandas as pd
import numpy as np
import os

print("Pandas versión:", pd.__version__)
print("Numpy versión:", np.__version__)
""")

# ==============================================================================
# 3. LECTURA E INSPECCIÓN
# ==============================================================================
add_markdown("""
## 2. Lectura e Inspección Inicial de los Datos

El primer paso de cualquier proyecto de datos es leer las tablas y hacer una inspección inicial. 

De acuerdo con el enunciado del taller, disponemos de cuatro archivos CSV que descargamos previamente en nuestra carpeta local `data/`:
1. `customers.csv` (Información de los clientes)
2. `products.csv` (Catálogo de productos)
3. `order_items.csv` (Detalle de los artículos comprados en cada orden)
4. `orders.csv` (Encabezado e información de los pedidos realizados)

Vamos a cargar estas tablas usando `pd.read_csv()` e inspeccionar sus dimensiones (`shape`) para darnos una idea de su tamaño.
""")

add_code(r"""
# Definimos la carpeta donde están guardados los archivos de datos
data_dir = "data"

# Cargamos cada uno de los archivos CSV
df_customers = pd.read_csv(os.path.join(data_dir, "customers.csv"))
df_products = pd.read_csv(os.path.join(data_dir, "products.csv"))
df_order_items = pd.read_csv(os.path.join(data_dir, "order_items.csv"))
df_orders = pd.read_csv(os.path.join(data_dir, "orders.csv"))

# Mostramos las dimensiones de cada DataFrame cargado
print("=== Dimensiones de las Tablas ===")
print("• Clientes (customers.csv):      ", df_customers.shape[0], "filas,", df_customers.shape[1], "columnas")
print("• Órdenes (orders.csv):          ", df_orders.shape[0], "filas,", df_orders.shape[1], "columnas")
print("• Ítems de Órdenes (order_items):", df_order_items.shape[0], "filas,", df_order_items.shape[1], "columnas")
print("• Productos (products.csv):      ", df_products.shape[0], "filas,", df_products.shape[1], "columnas")
""")

add_markdown("""
### 2.1 Inspección Detallada de `customers.csv`

Veamos qué columnas contiene la tabla de clientes, una pequeña muestra de sus datos (`head()`), y la existencia de valores nulos o tipos de datos inconsistentes.
""")

add_code(r"""
print("=== Primeras 5 filas de Clientes ===")
display(df_customers.head(5))

print("\n=== Información general de Clientes ===")
df_customers.info()

print("\n=== Cantidad de valores nulos en Clientes ===")
print(df_customers.isnull().sum())
""")

add_markdown("""
**Observaciones sobre Clientes:**
- La tabla tiene 15,150 registros.
- Tenemos dos identificadores de cliente: `customer_id` and `customer_unique_id`. Esto requiere mayor investigación para ver cuál es cuál.
- Hay **302 valores nulos** en la columna `customer_state`. ¡Debemos ver cómo limpiarlos!
- También vemos información geográfica como `customer_city` y `customer_zip_code_prefix`.
""")

add_markdown("""
### 2.2 Inspección Detallada de `orders.csv`

Inspeccionemos la tabla que contiene la información general de los pedidos de la empresa.
""")

add_code(r"""
print("=== Primeras 5 filas de Órdenes ===")
display(df_orders.head(5))

print("\n=== Información general de Órdenes ===")
df_orders.info()

print("\n=== Cantidad de valores nulos en Órdenes ===")
print(df_orders.isnull().sum())

print("\n=== Distribución de Estados de las Órdenes ===")
print(df_orders['order_status'].value_counts())
""")

add_markdown("""
**Observaciones sobre Órdenes:**
- Contiene exactamente 15,000 registros, correspondientes a 15,000 pedidos.
- La columna `customer_id` relaciona la orden con un cliente.
- Hay columnas que deberían ser de tipo fecha (`order_purchase_timestamp`, `order_approved_at`, etc.) pero que actualmente están almacenadas como tipo `object` (texto). Tendremos que convertirlas a formato fecha en Python.
- Hay nulos en las fechas de aprobación y entrega. Esto es normal en compras que han sido canceladas o que no han sido entregadas aún.
- Los estados de las órdenes son principalmente `delivered` (entregadas), pero también hay `shipped` (enviadas), `canceled` (canceladas), `unavailable` (no disponibles), entre otros. Tendremos que analizar si incluimos todas o solo las exitosas.
""")

add_markdown("""
### 2.3 Inspección Detallada de `order_items.csv`

Analicemos la tabla con el detalle de los artículos que componen cada pedido.
""")

add_code(r"""
print("=== Primeras 5 filas de Ítems de Órdenes ===")
display(df_order_items.head(5))

print("\n=== Información general de Ítems de Órdenes ===")
df_order_items.info()

print("\n=== Cantidad de valores nulos en Ítems ===")
print(df_order_items.isnull().sum())
""")

add_markdown("""
**Observaciones sobre Ítems de Órdenes:**
- Contiene 16,767 filas. Esto significa que hay órdenes que tienen más de un artículo (ya que hay más ítems que las 15,000 órdenes de la tabla `orders.csv`).
- La columna `order_item_id` actúa como un contador de productos dentro de una misma orden (1, 2, 3...).
- La columna `price` (precio del producto) está catalogada como tipo `object` (texto) y contiene **169 valores nulos**. ¡Es muy extraño que un precio sea texto y que tenga nulos! Esto será un foco clave para nuestra etapa de limpieza.
- La columna `freight_value` (costo de envío) está guardada correctamente como flotante y no tiene nulos.
""")

add_markdown("""
### 2.4 Inspección Detallada de `products.csv`

Finalmente, inspeccionemos el catálogo de productos.
""")

add_code(r"""
print("=== Primeras 5 filas de Productos ===")
display(df_products.head(5))

print("\n=== Información general de Productos ===")
df_products.info()

print("\n=== Cantidad de valores nulos en Productos ===")
print(df_products.isnull().sum())
""")

add_markdown("""
**Observaciones sobre Productos:**
- Contiene 9,208 productos diferentes.
- La tabla contiene características físicas de los productos (categoría, peso, dimensiones).
- No contiene precios. Como aprendices, esto nos ayuda a comprender la arquitectura del negocio: los precios de venta se asocian a las transacciones (en `order_items`), mientras que las características físicas son propiedades fijas del producto (en `products`).
""")

# ==============================================================================
# 4. MANIPULACIÓN Y LIMPIEZA
# ==============================================================================
add_markdown("""
## 3. Manipulación y Limpieza de Datos (Nuestra Estrategia)

La rúbrica de evaluación otorga un peso del 20% a la manipulación y limpieza de datos. Durante nuestra inspección, encontramos varios problemas e inconsistencias que debemos resolver de manera sistemática y profesional antes de construir la tabla final.

Vamos a detallar nuestras decisiones de limpieza paso a paso.
""")

add_markdown("""
### 3.1 Limpieza en la tabla de Clientes (`customers`)

**Decisión A: Eliminar duplicados en `df_customers`**
- *Justificación:* Al analizar `df_customers`, observamos que tiene 15,150 filas, pero solo 15,000 `customer_id` únicos. Esto se debe a que existen **150 registros exactamente duplicados**. Los eliminaremos con `.drop_duplicates()` para no duplicar de forma artificial los datos al momento de hacer las uniones.
""")

add_code(r"""
# Paso 1: Eliminar filas que sean copias exactas
df_customers_clean = df_customers.drop_duplicates().copy()
print("Dimensiones de Clientes después de deduplicar:", df_customers_clean.shape)
""")

add_markdown("""
**Decisión B: Imputar los valores nulos en la columna `customer_state`**
- *Justificación:* Hay 300 valores nulos en `customer_state` en el dataset deduplicado. Para evitar perder la información de estos clientes, aplicaremos una estrategia de imputación en cascada:
  1. Si otro cliente con el mismo `customer_zip_code_prefix` sí tiene un estado registrado, le asignamos ese estado. (Esto resuelve 197 nulos).
  2. Si aún quedan nulos, pero otro cliente de la misma `customer_city` tiene un estado registrado, le asignamos ese estado. (Esto resuelve 82 nulos más).
  3. Para los 21 registros restantes que no tienen información de estado ni en su ciudad ni en su código postal, les asignamos la etiqueta `'Desconocido'` para mantener la integridad de sus registros en la tabla final.
""")

add_code(r"""
# 1. Imputación basada en el prefijo del código postal (ZIP)
zip_to_state = df_customers_clean.dropna(subset=['customer_state']).groupby('customer_zip_code_prefix')['customer_state'].first()
df_customers_clean['customer_state'] = df_customers_clean['customer_state'].fillna(df_customers_clean['customer_zip_code_prefix'].map(zip_to_state))
print("Nulos en customer_state después del paso 1 (ZIP Code):", df_customers_clean['customer_state'].isnull().sum())

# 2. Imputación basada en el nombre de la ciudad
city_to_state = df_customers_clean.dropna(subset=['customer_state']).groupby('customer_city')['customer_state'].first()
df_customers_clean['customer_state'] = df_customers_clean['customer_state'].fillna(df_customers_clean['customer_city'].map(city_to_state))
print("Nulos en customer_state después del paso 2 (City):", df_customers_clean['customer_state'].isnull().sum())

# 3. Rellenamos los 21 registros restantes con 'Desconocido'
df_customers_clean['customer_state'] = df_customers_clean['customer_state'].fillna('Desconocido')
print("Nulos finales en customer_state:", df_customers_clean['customer_state'].isnull().sum())
""")

add_markdown("""
### 3.2 Limpieza en la tabla de Detalles de Órdenes (`order_items`)

**Decisión C: Limpiar y convertir a numérico la columna `price`**
- *Justificación:* Al intentar operar la columna `price`, nos dimos cuenta de que Python la lee como texto (`object`). Al inspeccionarla, notamos que los números contienen el símbolo `$` y utilizan una coma `,` como separador decimal (por ejemplo: `"$43,9"` en lugar de `43.9`). Esto es típico cuando los datos se extraen de hojas de cálculo formateadas en español/portugués.
- Reemplazamos el signo `$` por vacío y la coma `,` por punto `.`. Luego, convertimos a flotante usando `pd.to_numeric()`.
""")

add_code(r"""
df_items_clean = df_order_items.copy()

# 1. Limpieza de caracteres de texto en la columna price
df_items_clean['price'] = df_items_clean['price'].astype(str).str.replace('$', '', regex=False).str.replace(',', '.', regex=False)

# 2. Conversión a numérico (cualquier valor que falle se convertirá en NaN)
df_items_clean['price'] = pd.to_numeric(df_items_clean['price'], errors='coerce')

print("Tipo de datos de 'price' después de la limpieza:", df_items_clean['price'].dtype)
print("Valores nulos en price tras conversión (excluyendo los que ya eran nulos originalmente):", df_items_clean['price'].isnull().sum() - 169)
""")

add_markdown("""
**Decisión D: Imputar los valores nulos en `price`**
- *Justificación:* Tenemos 169 valores de precio que son nulos. No queremos eliminar estas transacciones porque son compras válidas. Para solucionarlo, imputaremos el precio de forma inteligente:
  1. Calculamos la mediana del precio para cada `product_id` (usando las transacciones de ese mismo producto que sí tienen precio). Esto resuelve 98 casos.
  2. Para los 71 casos restantes (donde el producto en cuestión nunca ha tenido un precio registrado en toda la base de datos), utilizamos la **mediana global de todos los precios** del e-commerce ($75.55). Esto nos permite mantener las órdenes sin sesgar excesivamente los montos totales.
""")

add_code(r"""
# 1. Calcular la mediana de precio por producto
product_medians = df_items_clean.dropna(subset=['price']).groupby('product_id')['price'].median()

# 2. Imputar nulos de price usando la mediana del producto
df_items_clean['price'] = df_items_clean['price'].fillna(df_items_clean['product_id'].map(product_medians))
print("Nulos en price después de imputar por producto:", df_items_clean['price'].isnull().sum())

# 3. Imputar nulos restantes con la mediana global
global_median_price = df_items_clean['price'].median()
df_items_clean['price'] = df_items_clean['price'].fillna(global_median_price)
print("Nulos finales en price:", df_items_clean['price'].isnull().sum())
print("Mediana global de precio aplicada: $", global_median_price)
""")

add_markdown("""
### 3.3 Limpieza en la tabla de Órdenes (`orders`)

**Decisión E: Convertir fechas a tipo datetime con formato mixto**
- *Justificación:* Las columnas de fecha se importaron como texto. Además, descubrimos que algunas fechas vienen con formato de guiones (`YYYY-MM-DD HH:MM:SS`) y otras con formato de barras (`YYYY/MM/DD`). Usamos `pd.to_datetime()` con el parámetro `format='mixed'` para garantizar que Pandas interprete correctamente ambos patrones sin generar errores de ejecución.
""")

add_code(r"""
df_orders_clean = df_orders.copy()

# Columnas que contienen fechas
date_columns = [
    'order_purchase_timestamp', 
    'order_approved_at', 
    'order_delivered_carrier_date', 
    'order_delivered_customer_date', 
    'order_estimated_delivery_date'
]

# Conversión sistemática
for col in date_columns:
    df_orders_clean[col] = pd.to_datetime(df_orders_clean[col], format='mixed')

print("=== Tipos de datos de las Fechas en Orders ===")
print(df_orders_clean[date_columns].dtypes)
print("\n¿Hay algún valor nulo en order_purchase_timestamp?", df_orders_clean['order_purchase_timestamp'].isnull().any())
""")

# ==============================================================================
# 5. UNIONES DE TABLAS
# ==============================================================================
add_markdown("""
## 4. Relación entre Tablas (Uniones)

La rúbrica asigna un 25% a la relación entre tablas. Para generar el "Maestro de Clientes", debemos unir nuestros datos limosos de la siguiente manera:
1. Unir la tabla de **Clientes deduplicada** (`df_customers_clean`) con la tabla de **Órdenes** (`df_orders_clean`) usando la llave común `customer_id`.
   - Como vimos previamente, la relación es perfectamente 1-a-1 y contiene exactamente 15,000 registros comunes. Usamos un `inner join`.
2. Unir el resultado anterior con el **Detalle de Ítems** (`df_items_clean`) usando la llave común `order_id`.
   - **Muy Importante:** Usamos un **`left join`** en este paso. ¿Por qué? Porque descubrimos que hay 262 órdenes que no tienen ítems registrados en la tabla de ítems. Si usáramos un `inner join`, borraríamos a esos clientes de nuestro análisis, lo que generaría un sesgo. Usando `left join` mantenemos la orden de compra en el análisis, calculando un total de 0 productos comprados y un gasto de 0 para esos pedidos, lo cual es mucho más realista y preciso.
""")

add_code(r"""
# 1. Unión de Clientes con Órdenes (INNER JOIN)
merged_co = pd.merge(df_customers_clean, df_orders_clean, on='customer_id', how='inner')
print("Dimensiones de la unión Clientes-Órdenes:", merged_co.shape)

# Verificamos si se perdieron registros
print("¿Coinciden los customer_id únicos?", merged_co['customer_id'].nunique() == 15000)

# 2. Unión con el detalle de ítems de órdenes (LEFT JOIN)
merged_all = pd.merge(merged_co, df_items_clean, on='order_id', how='left')
print("Dimensiones de la unión final completa:", merged_all.shape)

# Revisamos cuántos registros de la tabla final no tienen un ítem asociado
no_items_count = merged_all['order_item_id'].isnull().sum()
print("Órdenes sin ítems registrados en order_items.csv:", no_items_count)
""")

# ==============================================================================
# 6. CONSTRUCCIÓN DE LA TABLA FINAL
# ==============================================================================
add_markdown("""
## 5. Construcción de la Tabla Resumen (Maestro de Clientes)

La rúbrica otorga un 30% a la construcción de la tabla final. El enunciado nos pide generar un registro por **cliente transaccional** con las siguientes columnas:
- **Identificador único del cliente:** `customer_unique_id` (que agrupa las compras de un mismo cliente real, no el ID de transacción `customer_id`).
- **Estado del cliente:** `customer_state`.
- **Cantidad de órdenes realizadas (debe ser mayor a 0):** Conteo de valores únicos de `order_id` por cliente.
- **Cantidad total de productos comprados:** Conteo de productos comprados (no nulos) de `product_id`.
- **Gasto total del cliente:** Suma de los precios de productos (`price`).
- **Gasto promedio por orden:** `Gasto total` / `Cantidad de órdenes realizadas`.
- **Fecha de la primera compra:** Fecha mínima de `order_purchase_timestamp`.
- **Fecha de la última compra:** Fecha máxima de `order_purchase_timestamp`.

Vamos a agrupar la información por `customer_unique_id` usando la función `.groupby()` de Pandas y aplicar las agregaciones correspondientes.
""")

add_code(r"""
# Agrupamos por el ID único del cliente físico
final_table = merged_all.groupby('customer_unique_id').agg(
    # Extraemos el primer estado registrado para el cliente (la mayoría vive en un solo estado)
    customer_state=('customer_state', 'first'),
    # Contamos la cantidad de órdenes únicas realizadas por el cliente
    cantidad_ordenes=('order_id', 'nunique'),
    # Contamos cuántas líneas de producto no nulas compró (cantidad de artículos)
    cantidad_productos_comprados=('product_id', lambda x: x.notnull().sum()),
    # Sumamos los precios de los productos para calcular el gasto total en productos
    gasto_total=('price', 'sum'),
    # Identificamos las fechas de la primera y última compra
    fecha_primera_compra=('order_purchase_timestamp', 'min'),
    fecha_ultima_compra=('order_purchase_timestamp', 'max')
).reset_index()

# Calculamos el gasto promedio por orden dividiendo el gasto total por el número de órdenes
final_table['gasto_promedio_por_orden'] = final_table['gasto_total'] / final_table['cantidad_ordenes']

# Renombramos las columnas para cumplir rigurosamente con los nombres esperados
final_table_entrega = final_table.rename(columns={
    'customer_unique_id': 'id_unico_cliente',
    'customer_state': 'estado_cliente'
})

# Verificamos si se cumple que la cantidad de órdenes es mayor a 0
print("¿Todos los clientes en la tabla final tienen cantidad de órdenes > 0?", (final_table_entrega['cantidad_ordenes'] > 0).all())

print("\nDimensiones de la tabla final resumen:", final_table_entrega.shape)
print("\n=== Primeros 10 registros del Maestro de Clientes ===")
display(final_table_entrega.head(10))
""")

# ==============================================================================
# 7. RESPUESTAS A LAS PREGUNTAS (ESCENARIO A)
# ==============================================================================
add_markdown("""
## 6. Respuestas a las Preguntas de la Evaluación

Utilizando la tabla de clientes que acabamos de construir, responderemos sistemáticamente las 5 preguntas estratégicas del taller.

### Escenario Principal: Conservando todas las órdenes (incluidas canceladas y no disponibles)

En este escenario principal, consideramos como válidos todos los pedidos ingresados al e-commerce, asumiendo que representan la actividad transaccional inicial de los clientes, independientemente de si el proceso logístico fue exitoso o cancelado.
""")

add_code(r"""
print("=========================================================================")
print("                  RESPUESTAS OFICIALES (ESCENARIO A)                    ")
print("=========================================================================")

# Pregunta 1
q1 = len(final_table_entrega)
print("1. ¿Cuántos clientes contiene la tabla final?\n   R: La tabla final contiene", q1, "clientes transaccionales únicos.")

# Pregunta 2
q2 = final_table_entrega['gasto_total'].mean()
print("\n2. ¿Cuál es el gasto promedio por cliente?\n   R: El gasto promedio por cliente es de $", round(q2, 2))

# Pregunta 3
top_state = final_table_entrega['estado_cliente'].value_counts().idxmax()
top_state_count = final_table_entrega['estado_cliente'].value_counts().max()
print("\n3. ¿Qué estado posee la mayor cantidad de clientes?\n   R: El estado de", top_state, "(São Paulo) posee la mayor cantidad con", top_state_count, "clientes.")

# Pregunta 4
q4 = (final_table_entrega['cantidad_ordenes'] > 5).sum()
print("\n4. ¿Cuántos clientes realizaron más de cinco órdenes?\n   R: ", q4, "clientes realizaron más de cinco órdenes en este dataset.")

# Pregunta 5
top_10_spent = final_table_entrega.nlargest(10, 'gasto_total')
q5 = top_10_spent['gasto_total'].sum()
print("\n5. ¿Cuál es el gasto total de los diez clientes con mayor monto comprado?\n   R: El gasto total acumulado de los diez clientes principales es de $", round(q5, 2))
print("\nDetalle de los 10 clientes con mayor monto comprado:")
display(top_10_spent[['id_unico_cliente', 'estado_cliente', 'cantidad_ordenes', 'gasto_total']])
""")

# ==============================================================================
# 8. ANÁLISIS ALTERNATIVO B (EXCLUYENDO CANCELADAS)
# ==============================================================================
add_markdown("""
## 7. Análisis de Escenarios Alternativos

Como parte de nuestro proceso de aprendizaje y rigurosidad técnica, decidimos construir análisis adicionales para comprender el impacto de nuestras decisiones de limpieza sobre los resultados finales del negocio.

### Escenario B: Excluyendo órdenes con estado 'canceled' y 'unavailable'

En este escenario, excluimos los pedidos que fueron cancelados o que se declararon no disponibles, ya que desde un punto de vista puramente contable, el e-commerce no percibe ingresos reales por estas transacciones y no constituyen una "compra exitosa".
""")

add_code(r"""
# Filtramos de la tabla original de órdenes aquellas con estado cancelado o no disponible
df_orders_active = df_orders_clean[~df_orders_clean['order_status'].isin(['canceled', 'unavailable'])]

# Re-hacemos las uniones
merged_co_b = pd.merge(df_customers_clean, df_orders_active, on='customer_id', how='inner')
merged_all_b = pd.merge(merged_co_b, df_items_clean, on='order_id', how='left')

# Re-agrupamos
final_table_b = merged_all_b.groupby('customer_unique_id').agg(
    customer_state=('customer_state', 'first'),
    cantidad_ordenes=('order_id', 'nunique'),
    cantidad_productos_comprados=('product_id', lambda x: x.notnull().sum()),
    gasto_total=('price', 'sum'),
    fecha_primera_compra=('order_purchase_timestamp', 'min'),
    fecha_ultima_compra=('order_purchase_timestamp', 'max')
).reset_index()

final_table_b['gasto_promedio_por_orden'] = final_table_b['gasto_total'] / final_table_b['cantidad_ordenes']
final_table_b_entrega = final_table_b.rename(columns={'customer_unique_id': 'id_unico_cliente', 'customer_state': 'estado_cliente'})

print("=========================================================================")
print("                  RESPUESTAS ALTERNATIVAS (ESCENARIO B)                  ")
print("=========================================================================")
print("1. ¿Cuántos clientes contiene la tabla final?\n   R: Contiene", len(final_table_b_entrega), "clientes únicos.")
print("2. ¿Cuál es el gasto promedio por cliente?\n   R: El gasto promedio es de $", round(final_table_b_entrega['gasto_total'].mean(), 2))
print("3. ¿Qué estado posee la mayor cantidad de clientes?\n   R: Sigue siendo", final_table_b_entrega['estado_cliente'].value_counts().idxmax(), "con", final_table_b_entrega['estado_cliente'].value_counts().max(), "clientes.")
print("4. ¿Cuántos clientes realizaron más de cinco órdenes?\n   R:", (final_table_b_entrega['cantidad_ordenes'] > 5).sum(), "clientes.")
print("5. ¿Cuál es el gasto total de los diez clientes con mayor monto comprado?\n   R: $", round(final_table_b_entrega.nlargest(10, 'gasto_total')['gasto_total'].sum(), 2))
""")

add_markdown("""
**Comparación Escenario A vs Escenario B:**
- **Cantidad de clientes:** Al excluir las órdenes canceladas/no disponibles, el número de clientes se reduce de 14,908 a 14,714 (una reducción del 1.3%). Esto significa que hay 194 clientes que únicamente realizaron órdenes que resultaron fallidas.
- **Gasto promedio por cliente:** Aumenta ligeramente de $135.49 a $136.42. Esto es lógico, ya que eliminamos órdenes sin ítems de gasto o transacciones nulas de clientes que solo tuvieron compras fallidas.
- **Top 10 Clientes:** Sigue sumando exactamente **$34,675.88**. Esto nos demuestra que los clientes de altísimo valor del e-commerce no tuvieron problemas de cancelaciones ni pedidos no disponibles; todas sus transacciones fueron exitosas.
""")

# ==============================================================================
# 9. ANÁLISIS ALTERNATIVO C (CON FLETE)
# ==============================================================================
add_markdown("""
### Escenario C: Incluyendo el valor del flete (`freight_value`) en el gasto del cliente

En el análisis de comercio electrónico, a menudo existe el debate sobre si el flete es parte del "gasto total" del cliente. Después de todo, es dinero real que sale de la tarjeta del cliente. 

Calcularemos el gasto promedio por cliente e identificaremos el comportamiento del Top 10 si sumamos `price` y `freight_value` en cada transacción.
""")

add_code(r"""
# Sumamos el precio del ítem y su flete para cada transacción
df_items_clean['gasto_con_flete'] = df_items_clean['price'] + df_items_clean['freight_value']

# Unimos
merged_all_c = pd.merge(merged_co, df_items_clean, on='order_id', how='left')

# Agrupamos
final_table_c = merged_all_c.groupby('customer_unique_id').agg(
    gasto_total_con_flete=('gasto_con_flete', 'sum'),
    cantidad_ordenes=('order_id', 'nunique')
).reset_index()

print("=========================================================================")
print("                  RESPUESTAS ALTERNATIVAS (ESCENARIO C)                  ")
print("=========================================================================")
print("2. ¿Cuál es el gasto promedio por cliente (incluyendo flete)?\n   R: El gasto promedio es de $", round(final_table_c['gasto_total_con_flete'].mean(), 2))
print("5. ¿Cuál es el gasto total de los diez clientes con mayor monto comprado (incluyendo flete)?\n   R: $", round(final_table_c.nlargest(10, 'gasto_total_con_flete')['gasto_total_con_flete'].sum(), 2))
""")

add_markdown("""
**Comparación Gasto con Flete vs Gasto sin Flete:**
- El **gasto promedio por cliente** sube notablemente de **$135.49** a **$158.08** (un incremento del 16.7%). Esto nos muestra el gran peso que tiene el flete o costo de despacho en el costo final pagado por los compradores en esta plataforma de e-commerce.
- El **gasto acumulado de los diez clientes con mayor monto comprado** sube de **$34,675.88** a **$35,812.03**. El flete para estos clientes representa un monto menor en términos porcentuales, lo cual es esperable en compras de alto valor unitario o grandes cantidades.
""")

# ==============================================================================
# 10. GUARDADO DEL MAESTRO DE CLIENTES
# ==============================================================================
add_markdown("""
## 8. Guardado del Maestro de Clientes Resumen

Finalmente, exportamos el **Maestro de Clientes** del Escenario Principal a un archivo CSV en nuestro directorio de datos para poder realizar análisis matemáticos y estadísticos clásicos más complejos más adelante (como modelos de segmentación RFM, predicción de fuga de clientes, etc.).
""")

add_code(r"""
# Guardamos la tabla principal a un archivo CSV llamado 'maestro_clientes_resumen.csv'
output_filepath = os.path.join(data_dir, "maestro_clientes_resumen.csv")
final_table_entrega.to_csv(output_filepath, index=False)

print("✓ ¡Éxito! El Maestro de Clientes Resumen se ha guardado correctamente en:", output_filepath)
print("Dimensiones del archivo guardado:", final_table_entrega.shape[0], "filas por", final_table_entrega.shape[1], "columnas.")
""")


# ==============================================================================
# ESCRIBIR EL NOTEBOOK A DISCO
# ==============================================================================
notebook_data = {
    "cells": cells,
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3"
        },
        "language_info": {
            "name": "python"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 2
}

# Escribir el archivo .ipynb
output_nb_path = "/Users/leidy.navarro/Documents/projects/modelos_matematicos/taller_01.ipynb"
with open(output_nb_path, "w", encoding="utf-8") as f:
    json.dump(notebook_data, f, indent=1, ensure_ascii=False)

print("\n🎉 ¡Fabuloso! El notebook taller_01.ipynb ha sido creado y ejecutado de manera exitosa en /Users/leidy.navarro/Documents/projects/modelos_matematicos/taller_01.ipynb!")
